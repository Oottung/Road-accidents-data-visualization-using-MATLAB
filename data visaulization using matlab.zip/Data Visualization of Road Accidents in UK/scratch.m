

% We're storing the whole content of the Excel file in an array called  original_table 
%and we're not going to modify it throughout our whole project.

original_table=readtable("Kaagle_Upload.csv");

%After viewing the array there are many irrevelent information(columns)
%that are not required for our study
%So we create a new array and store those columns that we need.

main_table=original_table;

%We are going to delete every column except accident_index, vehicle_type, 
%skidding_overturning, sex_of_driver, age_of_driver, 
%number_of_vehicles, accident_severity, date, time, light_conditions, 
%weather_conditions, road_surface_conditions, urban_or_rural_area, 
%sex_of_casualty, age_band_of_casualty    

main_table=[main_table(:,1) main_table(:,3) main_table(:,8) main_table(:,15) main_table(:,16) main_table(:,32) main_table(:,31) main_table(:,34) main_table(:,36) main_table(:,49) main_table(:,50) main_table(:,51) main_table(:,54) main_table(:,59) main_table(:,61)]; 

%The above line eliminated all the unwanted columns.

%Now we focus on cleaning the data.

%------------------------------------------
%We now focus on handling missing data.
%As there are plenty of rows, we can just delete the rows which have NaN values.

main_table=rmmissing(main_table);

%To omit duplicate rows
main_table=unique(main_table);
%In our dataset -1 also is a missing value. We've use standardizeMissing function.
main_table = standardizeMissing(main_table,-1);
main_table=rmmissing(main_table);

%In weather_conditions column 9 represent unknown/missing data.
%We need to eliminate it. We can't use the above function as we just need
%only one column.

toDelete = main_table.weather_conditions == 9;
main_table(toDelete,:) = [];

%We now look at time column. We delete all the rows which has invalid time
timeparam=main_table.time;
hr=hour(timeparam);

toDelete = hr>24 & hr<=0;
hr(toDelete,:)=[]

%We found out that the number of rows in main_table and hr is same. So
%there are no invalid hour reading.

timeparam=main_table.time;
mins=minute(timeparam);

toDelete = mins>24 & mins<=0;
mins(toDelete,:)=[]
% The same result is seen for minutes also.

timeparam=main_table.time;
se=second(timeparam);

toDelete = se>24 & se<=0;
se(toDelete,:)=[]

%Same result is observed for seconds also.
%Invalid dates were handled as they were previously replaced by NaT.

%--------------------------------------------------------------------------

%Now that data processing part is complete, we'll move on to data
%visualization

% Vehicle type
%1-Pedal cycle
%2-Motorcycle 50cc and under
%3-Motorcycle 125cc and under
%4-Motorcycle over 125cc and up to 500cc
%5-Motorcycle over 500cc
%8-Taxi/Private hire car
%9-Car
%10-Minibus (8 - 16 passenger seats)
%11-Bus or coach (17 or more pass seats)
%16-Ridden horse
%17-Agricultural vehicle
%18-Tram
%19-Van / Goods 3.5 tonnes mgw or under
%20-Goods over 3.5t. and under 7.5t
%21-Goods 7.5 tonnes mgw and over
%22-Mobility scooter
%23-Electric motorcycle
%90-Other vehicle
%97-Motorcycle - unknown cc
%98-Goods vehicle - unknown weight

%Convert the vehicle_type in catagorical data.
vehicle_type=categorical(main_table.vehicle_type);
pie(vehicle_type);

%Skidding and overturning

%0-None
%1-Skidded
%2-Skidded and overturned
%3-Jackknifed
%4-Jackknifed and overturned
%5-Overturned

skidding_overturning=categorical(main_table.skidding_and_overturning);
histogram(skidding_overturning);

%sex_of_driver

%1-Male
%2-Female
%3-Not known

sex_of_driver=categorical(main_table.sex_of_driver);
pie(sex_of_driver);

%age_of_driver
%This is not a discrete datatype

histogram(main_table.age_of_driver);

%number_of_vehicles
histogram(main_table.number_of_vehicles);

%accident_severity
%1-Fatal
%2-Serious
%3-Slight

accident_severity=categorical(main_table.accident_severity);
histogram(accident_severity);
pie(accident_severity);

%date

timeparam=main_table.date;
mon=month(timeparam);
histogram(mon);

%time

%Plotting histogram to find which time of the day which has the most
%accidents.

histogram(hr);


%light_conditions

%1-Daylight
%4-Darkness - lights lit
%5-Darkness - lights unlit
%6-Darkness - no lighting
%7-Darkness - lighting unknown

light_condt=categorical(main_table.light_conditions);
pie(light_condt);
histogram(light_condt);

%weather_conditions

%1-Fine no high winds
%2-Raining no high winds
%3-Snowing no high winds
%4-Fine + high winds
%5-Raining + high winds
%6-Snowing + high winds
%7-Fog or mist
%8-Other
%9-Unknown

weath=categorical(main_table.weather_conditions);
histogram(weath);

%road_surface_conditions

%1-Dry
%2-Wet or damp
%3-Snow
%4-Frost or ice
%5-Flood over 3cm. deep
%6-Oil or diesel
%7-Mud

rd_cond=categorical(main_table.road_surface_conditions);
histogram(rd_cond);

%urban_or_rural_area

%1-Urban
%2-Rural

urb_rur=categorical(main_table.urban_or_rural_area);
pie(urb_rur);

%sex_of_casualty 

%1-Male
%2-Female

soc=categorical(main_table.sex_of_casualty);
pie(soc);

%age_band_of_casualty
%1 0 - 5
%2 6 - 10
%3 11 - 15
%4 16 - 20
%5 21 - 25
%6 27 - 35
%7 36 - 45
%8 46 - 55
%9 56 - 65
%10 66 - 75
%11-Over 75

abc=categorical(main_table.age_band_of_casualty);
pie(abc);










