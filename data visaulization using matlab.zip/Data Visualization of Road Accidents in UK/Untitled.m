% We're storing the whole content of the Excel file in an array called  original_table 
%and we're not going to modify it throughout our whole project.

original_table=readtable("Kaagle_Upload.csv");

%After viewing the array there are many irrevelent information(columns)
%that are not required for our study
%So we create a new array and store those columns that we need.

main_table=original_table;

%We are going to delete every column except accident_index, vehicle_type, 
%skidding_overturning, sex_of_driver, age_of_driver, 
%number_of_vehicles, accident_severity, date, time, light_conditions, 
%weather_conditions, road_surface_conditions, urban_or_rural_area, 
%sex_of_casualty, age_band_of_casualty    

main_table=[main_table(:,1) main_table(:,3) main_table(:,8) main_table(:,15) main_table(:,16) main_table(:,32) main_table(:,31) main_table(:,34) main_table(:,36) main_table(:,49) main_table(:,50) main_table(:,51) main_table(:,54) main_table(:,59) main_table(:,61)]; 

%The above line eliminated all the unwanted columns.

%Now we focus on cleaning the data.

%------------------------------------------
%We now focus on handling missing data.
%As there are plenty of rows, we can just delete the rows which have NaN values.

main_table=rmmissing(main_table);

%To omit duplicate rows
main_table=unique(main_table);
%In our dataset -1 also is a missing value. We've use standardizeMissing function.
main_table = standardizeMissing(main_table,-1);
main_table=rmmissing(main_table);

%In weather_conditions column 9 represent unknown/missing data.
%We need to eliminate it. We can't use the above function as we just need
%only one column.

toDelete = main_table.weather_conditions == 9;
main_table(toDelete,:) = [];

%We now look at time column. We delete all the rows which has invalid time
timeparam=main_table.time;
hr=hour(timeparam);

toDelete = hr>24 & hr<=0;
hr(toDelete,:)=[]

%We found out that the number of rows in main_table and hr is same. So
%there are no invalid hour reading.

timeparam=main_table.time;
mins=minute(timeparam);

toDelete = mins>24 & mins<=0;
mins(toDelete,:)=[]
% The same result is seen for minutes also.

timeparam=main_table.time;
second=second(timeparam);

toDelete = second>24 & second<=0;
second(toDelete,:)=[]

%Same result is observed for seconds also.

        




